'use strict'
var ripuApp = angular.module('ripu', ['ripu.controllers','ui.bootstrap'
    
]);
//demoApp.constant("CONSTANTS", {
//    getUserByIdUrl: "/user/getUser/",
//    getAllUsers: "/user/getAllUsers",
//    saveUser: "/user/saveUser"
//});